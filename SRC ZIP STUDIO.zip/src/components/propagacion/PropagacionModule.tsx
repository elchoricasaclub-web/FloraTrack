"use client";

import OperationalModuleShell, { OperationalModuleItem } from "../ui/OperationalModuleShell";

const items: OperationalModuleItem[] = [
  {
    id: "madres",
    title: "Banco de Plantas Madre",
    moduleName: "Propagación",
    area: "Genética",
    metric: "12 madres",
    status: "Activo",
    priority: "Alta",
    owner: "Jefe propagación",
    evidence: "Registro madre / genética / sanidad",
    description: "Control de plantas madre, estado sanitario, genética, ubicación, historial de cortes, vigor, trazabilidad y autorización para propagación.",
    progress: 88,
    actionLabel: "Abrir banco",
    flow: ["Selección", "Sanidad", "Corte", "Trazabilidad"],
  },
  {
    id: "clones",
    title: "Esquejes y Clones",
    moduleName: "Propagación",
    area: "Producción vegetal",
    metric: "240 clones",
    status: "En proceso",
    priority: "Alta",
    owner: "Operario propagación",
    evidence: "Registro de corte / bandeja / hormona",
    description: "Seguimiento de esquejes, bandejas, fecha de corte, operador, hormona, humedad, enraizamiento, mortalidad y lote destino.",
    progress: 64,
    actionLabel: "Ver clones",
    flow: ["Corte", "Bandeja", "Enraizado", "Trasplante"],
  },
  {
    id: "enraizamiento",
    title: "Enraizamiento",
    moduleName: "Propagación",
    area: "Control proceso",
    metric: "82%",
    status: "Pendiente revisión",
    priority: "Media",
    owner: "Supervisor cultivo",
    evidence: "Conteo raíces / humedad / temperatura",
    description: "Control del porcentaje de enraizamiento, días en propagador, condiciones ambientales, pérdidas y aprobación para traslado.",
    progress: 72,
    actionLabel: "Revisar lote",
    flow: ["Ingreso", "Ambiente", "Raíz", "Liberación"],
  },
];

export default function PropagacionModule() {
  return (
    <OperationalModuleShell
      eyebrow="FloraTrack GACP"
      title="Propagación"
      description="Gestión moderna de plantas madre, esquejes, clones, enraizamiento, control fitosanitario y trazabilidad genética."
      createLabel="+ Nueva Propagación"
      items={items}
    />
  );
}
