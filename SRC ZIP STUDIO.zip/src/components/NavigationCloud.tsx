"use client";

import { usePathname, useRouter } from "next/navigation";

const labels: Record<string, string> = {
  "dian": "DIAN / Comercio Exterior",
  "fne": "FNE / Fondo Nacional de Estupefacientes",
  "estado-app": "Estado de la App",
  "minjusticia": "Ministerio de Justicia",
  "dashboard-clasico": "Dashboard clásico",
  "command-center": "Command Center",
  "reportes-programados": "Automatización de Reportes",
  "regulatoria-api": "API Regulatoria Avanzada",
  "post-extraccion": "Post-Extracción GMP",
  "bho": "Extracción BHO",
  "live-rosin": "Live Rosin",
  "bubble-hash": "Bubble Hash",
  "ica": "ICA",
  "invima": "INVIMA",
  "peas": "PEAS",
  "documentos": "Documentos Controlados",
  "firmas": "Firmas Electrónicas",
  "part11": "Validación 21 CFR Part 11",
  "backups": "Backups y Restauración",
  "integraciones": "Conectores e Integraciones",
  "workflows": "Workflows QA",
  "automatizaciones": "Automatizaciones QA",
  "cambios": "Control de Cambios",
  "riesgos": "Gestión de Riesgos GxP",
  "entrenamiento": "Entrenamiento y Competencia",
  "equipos": "Equipos GMP",
  "proveedores": "Proveedores",
  "auditorias": "Auditorías Internas",
  "recepcion": "Recepción",
  "inventario": "Inventario",
  "calidad": "Calidad QA",
  "desviaciones": "Desviaciones / CAPA",
  "cultivos": "Cultivos",
  "propagacion": "Propagación",
  "cosecha": "Cosecha",
  "geneticas": "Genéticas",
  "predios": "Predios",
  "empresas": "Empresas y Licencias",
  "gis": "GIS / Mapa Operacional",
  "reportes": "Reportes y KPIs",
  "usuarios": "Usuarios y Accesos",
  "notificaciones": "Notificaciones y Alertas",
  "csv": "CSV / DataOps",
  "regulatorio": "Regulatorio",
  "residuos": "Residuos y Disposición",
  "recall": "Recall / Retiro",
  "retencion": "Retención y Estabilidad",
  "saneamiento": "Limpieza y Saneamiento",
  "plagas": "Manejo Integrado de Plagas"
};

function formatModuleName(pathname: string | null): string {
  if (!pathname || pathname === "/") return "Command Center";

  const firstSegment = pathname.split("/").filter(Boolean)[0] ?? "módulo";

  return labels[firstSegment] ?? firstSegment.charAt(0).toUpperCase() + firstSegment.slice(1);
}

export default function NavigationCloud() {
  const pathname = usePathname();
  const router = useRouter();

  const isDashboard = pathname === "/";
  const isSystemPath =
    pathname?.startsWith("/_next") ||
    pathname?.startsWith("/api") ||
    pathname?.startsWith("/favicon");

  if (isDashboard || isSystemPath) {
    return null;
  }

  function goBack() {
    if (typeof window !== "undefined" && window.history.length > 1) {
      router.back();
      return;
    }

    router.push("/");
  }

  return (
    <footer className="bg-slate-950 px-6 pb-8 pt-5 text-white print:hidden">
      <section className="mx-auto flex max-w-7xl flex-col gap-4 rounded-[2rem] border border-white/10 bg-white/[0.04] px-5 py-4 shadow-2xl backdrop-blur md:flex-row md:items-center md:justify-between">
        <div className="flex items-center gap-4">
          <div className="flex h-12 w-12 items-center justify-center rounded-3xl bg-gradient-to-br from-emerald-400 to-cyan-300 text-base font-black text-slate-950">
            F
          </div>

          <div>
            <p className="text-[11px] font-black uppercase tracking-[0.28em] text-emerald-300">
              FloraTrack Navigation
            </p>
            <p className="text-sm font-bold text-slate-200">
              {formatModuleName(pathname)}
            </p>
          </div>
        </div>

        <div className="flex flex-wrap gap-2">
          <button
            type="button"
            onClick={goBack}
            className="rounded-2xl border border-white/10 bg-white/[0.04] px-5 py-3 text-xs font-black text-slate-100 transition hover:bg-white hover:text-slate-950"
          >
            ← Atrás
          </button>

          <button
            type="button"
            onClick={() => router.push("/")}
            className="rounded-2xl bg-gradient-to-r from-emerald-400 to-cyan-300 px-5 py-3 text-xs font-black text-slate-950 shadow-lg shadow-emerald-950/20 transition hover:-translate-y-0.5"
          >
            Inicio / Command Center
          </button>
        </div>
      </section>
    </footer>
  );
}




