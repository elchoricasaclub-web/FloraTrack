"use client";

import { useEffect, useMemo, useState } from "react";
import { commandModules, type CommandModule, type ModuleRisk, type ModuleStatus } from "../../lib/floratrackCommandModules";

const filters = ["Todos", "Críticos", "QA", "Regulatorio", "Operación", "Sistema", "Automatización"];

const statusStyles: Record<ModuleStatus, string> = {
  Activo: "border-emerald-200 bg-emerald-50 text-emerald-700",
  Pendiente: "border-amber-200 bg-amber-50 text-amber-700",
  Completado: "border-blue-200 bg-blue-50 text-blue-700",
  Bloqueado: "border-slate-300 bg-slate-100 text-slate-700",
  Destacado: "border-cyan-200 bg-cyan-50 text-cyan-700",
  Vacío: "border-slate-200 bg-white text-slate-500",
  Error: "border-red-200 bg-red-50 text-red-700",
};

const riskStyles: Record<ModuleRisk, string> = {
  Bajo: "border-emerald-200 bg-emerald-50 text-emerald-700",
  Medio: "border-sky-200 bg-sky-50 text-sky-700",
  Alto: "border-amber-200 bg-amber-50 text-amber-700",
  Crítico: "border-red-200 bg-red-50 text-red-700",
};

function matchesFilter(module: CommandModule, filter: string) {
  if (filter === "Todos") return true;
  if (filter === "Críticos") return ["Alto", "Crítico"].includes(module.risk);
  if (filter === "QA") return ["QA", "GMP", "Validación", "Part 11", "Documental"].includes(module.group);
  if (filter === "Regulatorio") return ["Regulatorio", "Empresa", "GIS"].includes(module.group);
  if (filter === "Operación") return ["GACP", "Operación", "Ambiental", "Proveedor", "Extracción"].includes(module.group);
  if (filter === "Sistema") return ["Sistema", "DataOps", "Seguridad"].includes(module.group);
  if (filter === "Automatización") return ["Automatización", "Reportes", "Alertas"].includes(module.group);

  return true;
}

export default function CommandCenterPage() {
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState("Todos");
  const [selected, setSelected] = useState<CommandModule | null>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    setLoading(true);
    const timer = window.setTimeout(() => setLoading(false), 180);
    return () => window.clearTimeout(timer);
  }, [search, filter]);

  const filteredModules = useMemo(() => {
    const term = search.trim().toLowerCase();

    return commandModules.filter((module) => {
      const text = [
        module.title,
        module.subtitle,
        module.description,
        module.tag,
        module.group,
        module.status,
        module.risk,
        ...module.items,
        ...module.highlights,
      ]
        .join(" ")
        .toLowerCase();

      return text.includes(term) && matchesFilter(module, filter);
    });
  }, [search, filter]);

  const metrics = useMemo(() => {
    const critical = commandModules.filter((module) => module.risk === "Crítico").length;
    const high = commandModules.filter((module) => module.risk === "Alto").length;
    const avgProgress = Math.round(commandModules.reduce((sum, module) => sum + module.progress, 0) / commandModules.length);
    const automation = commandModules.filter((module) => ["Automatización", "Reportes", "Alertas"].includes(module.group)).length;

    return {
      modules: commandModules.length,
      critical,
      high,
      avgProgress,
      automation,
    };
  }, []);

  const priorityModules = commandModules
    .filter((module) => ["Crítico", "Alto"].includes(module.risk))
    .slice(0, 5);

  return (
    <main className="min-h-screen bg-slate-950 text-slate-950">
      <div className="min-h-screen bg-[radial-gradient(circle_at_top_left,rgba(16,185,129,0.22),transparent_32rem),radial-gradient(circle_at_top_right,rgba(56,189,248,0.18),transparent_30rem),linear-gradient(180deg,#f8fafc_0%,#eef6f5_45%,#f8fafc_100%)]">
        <div className="grid min-h-screen lg:grid-cols-[310px_1fr]">
          <aside className="hidden border-r border-white/70 bg-white/75 backdrop-blur-2xl lg:block">
            <div className="sticky top-0 flex h-screen flex-col">
              <header className="border-b border-slate-200/70 p-6">
                <div className="flex items-center gap-4">
                  <div className="relative grid h-14 w-14 place-items-center rounded-3xl bg-gradient-to-br from-emerald-500 to-cyan-400 text-2xl font-black text-white shadow-xl shadow-emerald-200">
                    F
                    <span className="absolute -right-1 -top-1 h-4 w-4 rounded-full border-2 border-white bg-emerald-400" />
                  </div>

                  <div>
                    <h1 className="text-2xl font-black tracking-tight">FloraTrack</h1>
                    <p className="text-xs font-black uppercase tracking-[0.25em] text-emerald-700">Command OS</p>
                  </div>
                </div>

                <div className="mt-6 rounded-3xl border border-slate-200 bg-white p-2 shadow-sm">
                  <div className="flex items-center gap-3 rounded-2xl bg-slate-50 px-4 py-3">
                    <span className="text-slate-400">⌕</span>
                    <input
                      value={search}
                      onChange={(event) => setSearch(event.target.value)}
                      placeholder="Buscar módulo..."
                      className="w-full bg-transparent text-sm font-bold outline-none placeholder:text-slate-400"
                    />
                  </div>
                </div>
              </header>

              <nav className="flex-1 overflow-auto p-4">
                <a href="/dashboard-clasico" className="mb-3 flex items-center justify-between rounded-2xl bg-slate-950 px-4 py-3 text-sm font-black text-white shadow-xl">
                  Dashboard clasico
                  <span className="rounded-full bg-white/15 px-3 py-1 text-xs">Volver</span>
                </a>

                <a href="/" className="mb-5 flex items-center justify-between rounded-2xl bg-gradient-to-r from-emerald-500 to-cyan-400 px-4 py-3 text-sm font-black text-white shadow-xl shadow-emerald-200">
                  Command Center
                  <span className="rounded-full bg-white/20 px-3 py-1 text-xs">Nuevo</span>
                </a>

                <p className="mb-3 px-3 text-xs font-black uppercase tracking-[0.22em] text-slate-400">Módulos</p>

                <div className="space-y-1">
                  {commandModules.map((module) => (
                    <a
                      key={module.href}
                      href={module.href}
                      className="group flex items-center justify-between gap-3 rounded-2xl px-4 py-3 text-sm font-black text-slate-700 transition hover:bg-white hover:text-slate-950 hover:shadow-sm"
                    >
                      <span className="line-clamp-2">{module.title}</span>
                      <span className="shrink-0 rounded-full bg-emerald-100 px-2.5 py-1 text-[11px] font-black text-emerald-800 group-hover:bg-slate-950 group-hover:text-white">
                        {module.tag}
                      </span>
                    </a>
                  ))}
                </div>
              </nav>
            </div>
          </aside>

          <section className="max-h-screen overflow-auto">
            <header className="sticky top-0 z-40 border-b border-white/70 bg-white/75 px-5 py-4 backdrop-blur-2xl md:px-8">
              <div className="flex flex-col gap-4 xl:flex-row xl:items-center xl:justify-between">
                <div>
                  <p className="text-xs font-black uppercase tracking-[0.28em] text-emerald-700">FloraTrack 2026</p>
                  <h2 className="text-3xl font-black tracking-tight md:text-5xl">Command Center</h2>
                </div>

                <div className="flex gap-2 overflow-x-auto pb-1">
                  <QuickAction href="/reportes-programados" label="Reportes Auto" gradient="from-blue-600 to-cyan-400" />
                  <QuickAction href="/riesgos" label="Riesgos" gradient="from-red-600 to-rose-500" />
                  <QuickAction href="/cambios" label="Cambios" gradient="from-cyan-500 to-emerald-500" />
                  <QuickAction href="/workflows" label="Workflows" gradient="from-pink-500 to-fuchsia-500" />
                </div>
              </div>
            </header>

            <div className="space-y-8 p-5 md:p-8">
              <section className="relative overflow-hidden rounded-[2.25rem] border border-white/10 bg-slate-950 p-7 text-white shadow-2xl md:p-10">
                <div className="absolute left-12 top-10 h-40 w-40 rounded-full bg-emerald-400/20 blur-3xl" />
                <div className="absolute bottom-6 right-24 h-40 w-40 rounded-full bg-cyan-400/20 blur-3xl" />
                <div className="absolute right-0 top-0 h-72 w-72 translate-x-20 -translate-y-20 rounded-full bg-white/5" />

                <div className="relative grid gap-8 xl:grid-cols-[1fr_340px] xl:items-center">
                  <div>
                    <div className="inline-flex rounded-full border border-emerald-300/30 bg-emerald-300/10 px-4 py-2 text-xs font-black uppercase tracking-[0.25em] text-emerald-200">
                      Premium Compliance OS
                    </div>

                    <h1 className="mt-6 max-w-5xl text-5xl font-black tracking-tight md:text-7xl">
                      Cumplimiento GACP/GMP visual, rápido y auditable.
                    </h1>

                    <p className="mt-5 max-w-4xl text-base font-semibold leading-8 text-slate-300 md:text-lg">
                      Una experiencia moderna para operar trazabilidad farmacéutica,
                      QA, riesgos, CAPA, firmas electrónicas, reportes programados,
                      cambios, APIs regulatorias y evidencia GMP desde un solo centro.
                    </p>

                    <div className="mt-8 flex flex-wrap gap-3">
                      <a href="/reportes-programados" className="rounded-2xl bg-white px-6 py-4 text-sm font-black text-slate-950 shadow-xl transition hover:-translate-y-1 hover:bg-emerald-100">
                        Automatizar reportes
                      </a>
                      <a href="/riesgos" className="rounded-2xl border border-white/15 bg-white/5 px-6 py-4 text-sm font-black text-white transition hover:-translate-y-1 hover:bg-white/10">
                        Ver riesgos GxP
                      </a>
                    </div>
                  </div>

                  <div className="space-y-4 rounded-[2rem] border border-white/10 bg-white/5 p-5 backdrop-blur">
                    <HeroMetric label="Score operativo" value="99%" progress={99} />
                    <HeroMetric label="Módulos vivos" value={metrics.modules} progress={100} />
                    <HeroMetric label="Automatización" value={metrics.automation} progress={82} />
                  </div>
                </div>
              </section>

              <section className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
                <MetricCard title="Módulos activos" value={metrics.modules} caption="Arquitectura total" tone="emerald" />
                <MetricCard title="Riesgo crítico" value={metrics.critical} caption="Máxima prioridad QA" tone="red" />
                <MetricCard title="Riesgo alto" value={metrics.high} caption="Seguimiento activo" tone="amber" />
                <MetricCard title="Madurez visual" value={`${metrics.avgProgress}%`} caption="Sistema en progreso" tone="blue" />
              </section>

              <section className="grid gap-6 xl:grid-cols-[1fr_380px]">
                <div className="space-y-5">
                  <div className="flex flex-col gap-4 xl:flex-row xl:items-end xl:justify-between">
                    <div>
                      <p className="text-xs font-black uppercase tracking-[0.25em] text-slate-400">Sistema modular</p>
                      <h3 className="mt-2 text-3xl font-black tracking-tight md:text-4xl">Módulos premium</h3>
                    </div>

                    <p className="text-sm font-black text-slate-500">{filteredModules.length} módulos visibles</p>
                  </div>

                  <div className="rounded-[2rem] border border-white/70 bg-white/75 p-4 shadow-sm backdrop-blur-xl">
                    <div className="flex gap-2 overflow-x-auto pb-1">
                      {filters.map((item) => (
                        <button
                          key={item}
                          type="button"
                          onClick={() => setFilter(item)}
                          className={`shrink-0 rounded-full border px-4 py-2 text-xs font-black transition ${
                            filter === item
                              ? "border-slate-950 bg-slate-950 text-white shadow-lg"
                              : "border-slate-200 bg-white text-slate-600 hover:border-emerald-300 hover:bg-emerald-50 hover:text-emerald-700"
                          }`}
                        >
                          {item}
                        </button>
                      ))}
                    </div>

                    <div className="mt-4 flex items-center gap-3 rounded-3xl border border-slate-200 bg-white px-4 py-3">
                      <span className="text-slate-400">⌕</span>
                      <input
                        value={search}
                        onChange={(event) => setSearch(event.target.value)}
                        placeholder="Buscar por módulo, estado, riesgo o proceso..."
                        className="w-full bg-transparent text-sm font-bold outline-none placeholder:text-slate-400"
                      />
                    </div>
                  </div>

                  {loading ? (
                    <div className="grid gap-5 xl:grid-cols-2">
                      <SkeletonCard />
                      <SkeletonCard />
                      <SkeletonCard />
                      <SkeletonCard />
                    </div>
                  ) : filteredModules.length === 0 ? (
                    <EmptyState
                      title="No encontramos módulos"
                      description="Limpia la búsqueda o cambia de filtro para ver nuevamente el ecosistema FloraTrack."
                      onReset={() => {
                        setSearch("");
                        setFilter("Todos");
                      }}
                    />
                  ) : (
                    <div className="grid gap-5 xl:grid-cols-2">
                      {filteredModules.map((module, index) => (
                        <ModuleCard
                          key={module.href}
                          module={module}
                          index={index}
                          onInspect={() => setSelected(module)}
                        />
                      ))}
                    </div>
                  )}
                </div>

                <aside className="space-y-5">
                  <Panel title="Actividad prioritaria" subtitle="Qué revisar primero">
                    <div className="space-y-3">
                      <NotificationCard title="Reportes programados" description="Automatiza salida ejecutiva con evidencia y decisión QA." tone="blue" />
                      <NotificationCard title="Riesgos GxP" description="RPN, mitigación y CAPA con seguimiento visual." tone="red" />
                      <NotificationCard title="Control de cambios" description="Impacto documental, validación y entrenamiento." tone="cyan" />
                    </div>
                  </Panel>

                  <Panel title="Módulos destacados" subtitle="Alto impacto GMP">
                    <div className="space-y-3">
                      {priorityModules.map((module) => (
                        <MiniModule key={module.href} module={module} onClick={() => setSelected(module)} />
                      ))}
                    </div>
                  </Panel>
                </aside>
              </section>
            </div>
          </section>
        </div>
      </div>

      <MobileNav />

      {selected && (
        <DetailDrawer module={selected} onClose={() => setSelected(null)} />
      )}
    </main>
  );
}

function QuickAction({ href, label, gradient }: { href: string; label: string; gradient: string }) {
  return (
    <a href={href} className={`shrink-0 rounded-2xl bg-gradient-to-r ${gradient} px-5 py-3 text-sm font-black text-white shadow-lg transition hover:-translate-y-0.5`}>
      {label}
    </a>
  );
}

function HeroMetric({ label, value, progress }: { label: string; value: string | number; progress: number }) {
  return (
    <div className="rounded-[1.5rem] border border-white/10 bg-white/5 p-4">
      <div className="flex items-end justify-between">
        <div>
          <p className="text-xs font-black uppercase tracking-[0.2em] text-slate-400">{label}</p>
          <p className="mt-2 text-3xl font-black text-white">{value}</p>
        </div>
        <span className="text-xs font-black text-emerald-200">Live</span>
      </div>

      <div className="mt-4 h-2 overflow-hidden rounded-full bg-white/10">
        <div className="h-full rounded-full bg-gradient-to-r from-emerald-400 to-cyan-300 transition-all" style={{ width: `${progress}%` }} />
      </div>
    </div>
  );
}

function MetricCard({
  title,
  value,
  caption,
  tone,
}: {
  title: string;
  value: string | number;
  caption: string;
  tone: "emerald" | "red" | "amber" | "blue";
}) {
  const color =
    tone === "emerald"
      ? "from-emerald-500 to-cyan-400"
      : tone === "red"
      ? "from-red-600 to-rose-500"
      : tone === "amber"
      ? "from-amber-500 to-orange-400"
      : "from-blue-600 to-cyan-400";

  return (
    <article className="group rounded-[2rem] border border-white/70 bg-white/80 p-5 shadow-sm backdrop-blur-xl transition hover:-translate-y-1 hover:shadow-2xl">
      <div className={`mb-5 h-2 w-16 rounded-full bg-gradient-to-r ${color}`} />
      <p className="text-xs font-black uppercase tracking-[0.22em] text-slate-400">{title}</p>
      <p className="mt-3 text-4xl font-black tracking-tight text-slate-950">{value}</p>
      <p className="mt-2 text-sm font-semibold text-slate-500">{caption}</p>
    </article>
  );
}

function ModuleCard({ module, index, onInspect }: { module: CommandModule; index: number; onInspect: () => void }) {
  return (
    <article
      className="group relative overflow-hidden rounded-[2rem] border border-white/70 bg-white/85 p-6 shadow-sm backdrop-blur-xl transition duration-300 hover:-translate-y-1 hover:shadow-2xl"
      style={{ animation: "fadeInUp 0.35s ease both", animationDelay: `${Math.min(index * 24, 280)}ms` }}
    >
      <div className={`absolute right-0 top-0 h-32 w-32 translate-x-8 -translate-y-8 rounded-full bg-gradient-to-br ${module.accent} opacity-15 blur-xl transition group-hover:scale-125`} />

      <div className="relative flex items-start justify-between gap-4">
        <div className={`grid h-14 w-14 place-items-center rounded-3xl bg-gradient-to-br ${module.accent} text-xl font-black text-white shadow-xl`}>
          {module.tag.slice(0, 2)}
        </div>

        <div className="flex gap-2">
          <Badge className={statusStyles[module.status]}>{module.status}</Badge>
          <Badge className={riskStyles[module.risk]}>{module.risk}</Badge>
        </div>
      </div>

      <div className="relative mt-5">
        <p className="text-xs font-black uppercase tracking-[0.22em] text-emerald-700">{module.subtitle}</p>
        <h3 className="mt-2 text-2xl font-black tracking-tight text-slate-950">{module.title}</h3>
        <p className="mt-3 min-h-20 text-sm font-semibold leading-7 text-slate-600">{module.description}</p>
      </div>

      <div className="relative mt-5">
        <div className="mb-2 flex items-center justify-between text-xs font-black text-slate-500">
          <span>Progreso del módulo</span>
          <span>{module.progress}%</span>
        </div>

        <div className="h-2 overflow-hidden rounded-full bg-slate-100">
          <div className={`h-full rounded-full bg-gradient-to-r ${module.accent}`} style={{ width: `${module.progress}%` }} />
        </div>
      </div>

      <div className="relative mt-5 flex flex-wrap gap-2">
        {module.items.slice(0, 5).map((item) => (
          <span key={item} className="rounded-full bg-slate-100 px-3 py-1 text-xs font-black text-slate-600">
            {item}
          </span>
        ))}
      </div>

      <div className="relative mt-6 flex flex-wrap gap-3">
        <a href={module.href} className="rounded-2xl bg-slate-950 px-5 py-3 text-sm font-black text-white transition hover:bg-emerald-600">
          Abrir módulo
        </a>

        <button type="button" onClick={onInspect} className="rounded-2xl border border-slate-200 bg-white px-5 py-3 text-sm font-black text-slate-950 transition hover:bg-slate-100">
          Vista rápida
        </button>
      </div>
    </article>
  );
}

function Badge({ children, className }: { children: React.ReactNode; className: string }) {
  return (
    <span className={`inline-flex items-center rounded-full border px-3 py-1 text-xs font-black ${className}`}>
      {children}
    </span>
  );
}

function Panel({ title, subtitle, children }: { title: string; subtitle: string; children: React.ReactNode }) {
  return (
    <section className="rounded-[2rem] border border-white/70 bg-white/85 p-5 shadow-sm backdrop-blur-xl">
      <p className="text-xs font-black uppercase tracking-[0.22em] text-slate-400">{subtitle}</p>
      <h3 className="mt-1 text-2xl font-black text-slate-950">{title}</h3>
      <div className="mt-5">{children}</div>
    </section>
  );
}

function NotificationCard({ title, description, tone }: { title: string; description: string; tone: "blue" | "red" | "cyan" }) {
  const className =
    tone === "blue"
      ? "border-blue-200 bg-blue-50 text-blue-800"
      : tone === "red"
      ? "border-red-200 bg-red-50 text-red-800"
      : "border-cyan-200 bg-cyan-50 text-cyan-800";

  return (
    <div className={`rounded-[1.5rem] border p-4 ${className}`}>
      <p className="text-sm font-black">{title}</p>
      <p className="mt-1 text-sm font-semibold opacity-80">{description}</p>
    </div>
  );
}

function MiniModule({ module, onClick }: { module: CommandModule; onClick: () => void }) {
  return (
    <button type="button" onClick={onClick} className="w-full rounded-[1.5rem] border border-slate-200 bg-white p-4 text-left shadow-sm transition hover:-translate-y-0.5 hover:shadow-xl">
      <div className="flex items-center justify-between gap-3">
        <div>
          <p className="text-sm font-black text-slate-950">{module.title}</p>
          <p className="mt-1 text-xs font-bold text-slate-500">{module.subtitle}</p>
        </div>
        <Badge className={riskStyles[module.risk]}>{module.risk}</Badge>
      </div>
    </button>
  );
}

function SkeletonCard() {
  return (
    <div className="rounded-[2rem] border border-white/70 bg-white/75 p-6 shadow-sm">
      <div className="h-12 w-12 animate-pulse rounded-3xl bg-slate-100" />
      <div className="mt-6 h-7 w-2/3 animate-pulse rounded-xl bg-slate-100" />
      <div className="mt-3 h-4 w-full animate-pulse rounded-xl bg-slate-100" />
      <div className="mt-2 h-4 w-5/6 animate-pulse rounded-xl bg-slate-100" />
      <div className="mt-6 h-11 w-36 animate-pulse rounded-2xl bg-slate-100" />
    </div>
  );
}

function EmptyState({ title, description, onReset }: { title: string; description: string; onReset: () => void }) {
  return (
    <div className="rounded-[2rem] border border-dashed border-slate-300 bg-white/80 p-10 text-center shadow-sm">
      <div className="mx-auto grid h-16 w-16 place-items-center rounded-3xl bg-slate-950 text-2xl text-white">◇</div>
      <h3 className="mt-5 text-2xl font-black text-slate-950">{title}</h3>
      <p className="mx-auto mt-2 max-w-xl text-sm font-semibold leading-6 text-slate-500">{description}</p>
      <button type="button" onClick={onReset} className="mt-6 rounded-2xl bg-emerald-600 px-5 py-3 text-sm font-black text-white transition hover:bg-emerald-500">
        Limpiar filtros
      </button>
    </div>
  );
}

function DetailDrawer({ module, onClose }: { module: CommandModule; onClose: () => void }) {
  return (
    <div className="fixed inset-0 z-[9999] bg-slate-950/40 p-4 backdrop-blur-sm" onClick={onClose}>
      <aside className="ml-auto flex h-full w-full max-w-xl flex-col overflow-hidden rounded-[2rem] bg-white shadow-2xl" onClick={(event) => event.stopPropagation()}>
        <header className={`bg-gradient-to-br ${module.accent} p-6 text-white`}>
          <div className="flex items-start justify-between gap-4">
            <div>
              <p className="text-xs font-black uppercase tracking-[0.25em] text-white/70">{module.tag}</p>
              <h2 className="mt-3 text-4xl font-black tracking-tight">{module.title}</h2>
              <p className="mt-2 text-sm font-semibold text-white/80">{module.subtitle}</p>
            </div>

            <button type="button" onClick={onClose} className="rounded-2xl bg-white/15 px-4 py-2 text-xs font-black text-white transition hover:bg-white/25">
              Cerrar
            </button>
          </div>
        </header>

        <div className="flex-1 space-y-5 overflow-auto p-6">
          <div className="flex flex-wrap gap-2">
            <Badge className={statusStyles[module.status]}>{module.status}</Badge>
            <Badge className={riskStyles[module.risk]}>Riesgo {module.risk}</Badge>
            <Badge className="border-slate-200 bg-slate-50 text-slate-700">{module.group}</Badge>
          </div>

          <p className="text-base font-semibold leading-8 text-slate-600">{module.description}</p>

          <div className="rounded-[1.5rem] bg-slate-50 p-5">
            <p className="text-xs font-black uppercase tracking-[0.2em] text-slate-400">Items internos</p>
            <div className="mt-4 grid gap-3">
              {module.items.map((item) => (
                <div key={item} className="flex items-center justify-between rounded-2xl bg-white px-4 py-3 text-sm font-bold text-slate-700 shadow-sm">
                  <span>{item}</span>
                  <span className="text-emerald-600">Activo</span>
                </div>
              ))}
            </div>
          </div>

          <div className="rounded-[1.5rem] bg-slate-950 p-5 text-white">
            <p className="text-xs font-black uppercase tracking-[0.2em] text-slate-400">Highlights</p>
            <div className="mt-4 flex flex-wrap gap-2">
              {module.highlights.map((item) => (
                <span key={item} className="rounded-full bg-white/10 px-3 py-2 text-xs font-black text-white">
                  {item}
                </span>
              ))}
            </div>
          </div>
        </div>

        <footer className="border-t border-slate-200 p-6">
          <a href={module.href} className="block rounded-2xl bg-slate-950 px-5 py-4 text-center text-sm font-black text-white transition hover:bg-emerald-600">
            Abrir módulo completo
          </a>
        </footer>
      </aside>
    </div>
  );
}

function MobileNav() {
  return (
    <nav className="fixed bottom-3 left-3 right-3 z-50 grid grid-cols-4 gap-2 rounded-[1.5rem] border border-white/70 bg-white/90 p-2 shadow-2xl backdrop-blur-xl lg:hidden">
      <a href="/" className="rounded-2xl bg-slate-950 px-3 py-3 text-center text-xs font-black text-white">Inicio</a>
      <a href="/riesgos" className="rounded-2xl px-3 py-3 text-center text-xs font-black text-slate-700">Riesgos</a>
      <a href="/reportes-programados" className="rounded-2xl px-3 py-3 text-center text-xs font-black text-slate-700">Reportes</a>
      <a href="/workflows" className="rounded-2xl px-3 py-3 text-center text-xs font-black text-slate-700">QA</a>
    </nav>
  );
}


