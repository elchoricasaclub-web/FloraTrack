export type ModuleGroup =
  | "GACP"
  | "GMP"
  | "QA"
  | "Base"
  | "Audit"
  | "Supplier"
  | "Sanitation"
  | "Pest"
  | "Waste"
  | "Recall"
  | "Stability"
  | "Security"
  | "Company"
  | "Reports"
  | "GIS"
  | "Notifications"
  | "DataOps"
  | "Regulatory"
  | "eSign"
  | "Validation"
  | "Backup"
  | "Integrations"
  | "Workflow"
  | "Automation"
  | "Change"
  | "Risk"
  | "ReportAutomation"
  | "RegulatoryApi"
  | "Extraction";

export type ModuleItem = {
  title: string;
  subtitle: string;
  description: string;
  href: string;
  tag: string;
  status: "Activo" | "Pendiente" | "Completado" | "Bloqueado" | "Destacado" | "Vacío" | "Error";
  risk: "Bajo" | "Medio" | "Alto" | "Crítico";
  group: ModuleGroup;
};

export type DashboardAction = {
  href: string;
  label: string;
  className: string;
};

export const primaryModules: ModuleItem[] = [
  { title: "Cultivos", subtitle: "Producción agrícola GACP", description: "Registro validado de cultivos, predio, genética, área, responsable, evidencia y trazabilidad.", href: "/cultivos", tag: "GACP", status: "Activo", risk: "Medio", group: "GACP" },
  { title: "Propagación", subtitle: "Clones, madres y trazabilidad vegetal", description: "Control de propagación, genética, etapa, ambiente, evidencia, responsable y soporte técnico.", href: "/propagacion", tag: "GACP", status: "Activo", risk: "Medio", group: "GACP" },
  { title: "Cosecha", subtitle: "Corte, lote y rendimiento", description: "Trazabilidad de cosecha, lote, biomasa, responsables, rendimientos y control documental.", href: "/cosecha", tag: "GACP", status: "Activo", risk: "Medio", group: "GACP" },
  { title: "Genéticas", subtitle: "Banco genético y variedades", description: "Control de variedades, madres, códigos, características, estado y trazabilidad genética.", href: "/geneticas", tag: "GACP", status: "Activo", risk: "Medio", group: "GACP" },
  { title: "Empresas y Licencias", subtitle: "Multiempresa, sedes y alcance", description: "Control multiempresa de razón social, sedes, licencias, responsables, alcance autorizado, estado GACP/GMP, auditoría, evidencia, QA y CAPA.", href: "/empresas", tag: "Company", status: "Activo", risk: "Alto", group: "Company" },
  { title: "GIS / Mapa Operacional", subtitle: "Predios, coordenadas y zonas críticas", description: "Control georreferenciado de empresas, predios, áreas, zonas críticas, coordenadas, uso operativo, estado GACP/GMP, riesgo, evidencia, desviaciones, CAPA y decisión QA.", href: "/gis", tag: "GIS", status: "Activo", risk: "Medio", group: "GIS" },
  { title: "Predios", subtitle: "Infraestructura agrícola base", description: "Registro de predios, áreas, ubicación, capacidad productiva y condiciones de cumplimiento.", href: "/predios", tag: "Base", status: "Activo", risk: "Bajo", group: "Base" },
  { title: "Recepción", subtitle: "Ingreso y liberación inicial", description: "Control de ingreso de material vegetal, lotes, insumos, empaque, estado sanitario y decisión QA.", href: "/recepcion", tag: "GACP/GMP", status: "Activo", risk: "Alto", group: "QA" },
  { title: "Inventario", subtitle: "Almacén, stock y estado QA", description: "Movimientos de inventario, ubicación, cantidad, cuarentena, liberación QA y condiciones de almacenamiento.", href: "/inventario", tag: "GMP", status: "Activo", risk: "Alto", group: "GMP" },
  { title: "Calidad QA", subtitle: "Muestreo y control analítico", description: "Registro de muestras, análisis, laboratorio, resultados, veredicto QA, evidencia y trazabilidad.", href: "/calidad", tag: "QA", status: "Activo", risk: "Alto", group: "QA" },
  { title: "Desviaciones / CAPA", subtitle: "No conformidades y causa raíz", description: "Investigación, impacto, causa raíz, acciones inmediatas, CAPA, cierre QA y eficacia.", href: "/desviaciones", tag: "CAPA", status: "Activo", risk: "Crítico", group: "QA" },
  { title: "Auditorías Internas", subtitle: "Autoinspecciones GACP/GMP", description: "Auditorías, hallazgos, evidencia objetiva, acciones requeridas, responsable y cierre QA.", href: "/auditorias", tag: "Audit", status: "Activo", risk: "Alto", group: "Audit" },
  { title: "Documentos Controlados", subtitle: "SOP, versiones y aprobación QA", description: "Control documental de SOP, formatos, versiones, vigencia, obsolescencia, entrenamiento y evidencia.", href: "/documentos", tag: "GMP", status: "Activo", risk: "Alto", group: "GMP" },
  { title: "Firmas Electrónicas", subtitle: "Firma, hash y registros electrónicos", description: "Control de firmas electrónicas, registro asociado, firmante, razón, significado, identidad, MFA, hash, política de firma, decisión QA, evidencia, desviaciones y CAPA.", href: "/firmas", tag: "eSign", status: "Activo", risk: "Crítico", group: "eSign" },
  { title: "Validación 21 CFR Part 11", subtitle: "Validación del sistema y CSV", description: "Control de URS, matriz de riesgo, protocolos IQ/OQ/PQ, pruebas, audit trail, firmas electrónicas, integridad de datos, release, evidencia, desviaciones, CAPA y aprobación QA.", href: "/part11", tag: "Part 11", status: "Activo", risk: "Crítico", group: "Validation" },
  { title: "Backups y Restauración", subtitle: "Base de datos, restore e integridad", description: "Control de backups, restauración, snapshots, retención de datos, cifrado, hash, pruebas de restore, evidencia, desviaciones, CAPA y decisión QA.", href: "/backups", tag: "Backup", status: "Activo", risk: "Crítico", group: "Backup" },
  { title: "Conectores e Integraciones", subtitle: "API, webhooks y sistemas externos", description: "Control de integraciones externas, APIs, webhooks, LIMS, ERP, laboratorio externo, autenticación, cifrado, audit trail, integridad, evidencia, desviaciones, CAPA y decisión QA.", href: "/integraciones", tag: "API", status: "Activo", risk: "Alto", group: "Integrations" },
  { title: "Workflows QA", subtitle: "Aprobaciones, SLA y escalamiento", description: "Control de flujos QA, aprobaciones, liberaciones, firmas electrónicas, SLA, escalamiento, audit trail, evidencia, desviaciones, CAPA y cierre.", href: "/workflows", tag: "Workflow", status: "Activo", risk: "Alto", group: "Workflow" },
  { title: "Automatizaciones QA", subtitle: "Tareas y jobs programados", description: "Control de reportes programados, jobs automáticos, frecuencias, cron, reglas de ejecución, audit trail, firmas electrónicas, escalamiento, evidencia, desviaciones, CAPA y decisión QA.", href: "/automatizaciones", tag: "Jobs", status: "Activo", risk: "Alto", group: "Automation" },
  { title: "Automatización de Reportes", subtitle: "Reportes programados y distribución", description: "Control especializado de reportes programados, frecuencias, origen de datos, formato de salida, destinatarios, ejecución, audit trail, errores, firma electrónica, CAPA y aprobación QA.", href: "/reportes-programados", tag: "Reports Auto", status: "Activo", risk: "Alto", group: "ReportAutomation" },
  { title: "Control de Cambios", subtitle: "Change control GMP/GACP", description: "Gestión formal de cambios sobre procesos, documentos, equipos, proveedores, software, integraciones, validaciones, impacto GxP, entrenamiento, regulación, CAPA, eficacia y aprobación QA.", href: "/cambios", tag: "Change", status: "Activo", risk: "Alto", group: "Change" },
  { title: "Gestión de Riesgos GxP", subtitle: "QRM, RPN, mitigación y eficacia", description: "Control de riesgos GACP/GMP, QA/QC, regulatorios, integridad de datos, proveedores, software, Part 11, severidad, probabilidad, detectabilidad, RPN, mitigación, CAPA, eficacia y decisión QA.", href: "/riesgos", tag: "Risk", status: "Activo", risk: "Alto", group: "Risk" },
  { title: "API Regulatoria Avanzada", subtitle: "Autoridades, endpoints y datos regulatorios", description: "Control de conexiones con autoridades, APIs regulatorias, radicaciones externas, consulta de estados, envío de reportes, credenciales referenciadas, cifrado, audit trail, integridad de datos, desviaciones, CAPA y decisión QA.", href: "/regulatoria-api", tag: "Reg API", status: "Activo", risk: "Alto", group: "RegulatoryApi" },
  { title: "Entrenamiento y Competencia", subtitle: "Personal, SOP y liberación operacional", description: "Control de entrenamiento por colaborador, SOP, versión documental, instructor, evaluación, competencia, evidencia, QA y reentrenamiento.", href: "/entrenamiento", tag: "GMP", status: "Activo", risk: "Alto", group: "GMP" },
  { title: "Equipos GMP", subtitle: "Calibración y mantenimiento", description: "Control de equipos críticos, códigos de activo, calibración, mantenimiento, certificados, desviaciones, CAPA y liberación QA.", href: "/equipos", tag: "GMP", status: "Activo", risk: "Alto", group: "GMP" },
  { title: "Proveedores", subtitle: "Calificación GMP/GACP", description: "Evaluación, calificación, criticidad, riesgo, documentación, auditoría, evidencia, decisión QA y reevaluación de proveedores.", href: "/proveedores", tag: "Supplier", status: "Activo", risk: "Alto", group: "Supplier" },
  { title: "Limpieza y Saneamiento", subtitle: "SOP, higiene y liberación QA", description: "Control GMP de limpieza, desinfección, SOP, productos, concentraciones, inspección preoperacional, hisopado, CAPA y liberación QA.", href: "/saneamiento", tag: "GMP", status: "Activo", risk: "Alto", group: "Sanitation" },
  { title: "Manejo Integrado de Plagas", subtitle: "MIP, trampas y liberación QA", description: "Control GACP/GMP de inspecciones, trampas, hallazgos, actividad de plagas, productos aplicados, proveedor, evidencia, CAPA y liberación QA.", href: "/plagas", tag: "MIP", status: "Activo", risk: "Alto", group: "Pest" },
  { title: "Residuos y Disposición", subtitle: "Gestión ambiental GMP/GACP", description: "Control de residuos por área, lote, clasificación de riesgo, cantidad, tratamiento, gestor autorizado, disposición final, certificado, evidencia, QA y CAPA.", href: "/residuos", tag: "Waste", status: "Activo", risk: "Alto", group: "Waste" },
  { title: "Recall / Retiro", subtitle: "Retiro de producto GMP", description: "Gestión de alertas, bloqueo de lote, retiro preventivo u obligatorio, comunicación a autoridad, recuperación, desviación, CAPA, evidencia y cierre QA.", href: "/recall", tag: "Recall", status: "Activo", risk: "Crítico", group: "Recall" },
  { title: "Retención y Estabilidad", subtitle: "Muestras, custodia y estabilidad", description: "Control de muestras de retención, contramuestras, estabilidad, custodia, almacenamiento, vencimiento, revisión, evidencia, desviaciones, CAPA y decisión QA.", href: "/retencion", tag: "GMP", status: "Activo", risk: "Alto", group: "Stability" },
  { title: "Usuarios y Accesos", subtitle: "Roles, permisos y seguridad GMP", description: "Control de usuarios, roles, permisos, MFA, firma electrónica, aprobación QA, revisión periódica de accesos, segregación de funciones, evidencia y CAPA.", href: "/usuarios", tag: "Security", status: "Activo", risk: "Crítico", group: "Security" },
  { title: "Reportes y KPIs", subtitle: "Cumplimiento ejecutivo GACP/GMP", description: "Registro de reportes ejecutivos, KPIs, periodos, módulos incluidos, hallazgos, riesgos, acciones requeridas, evidencia, CAPA y decisión QA.", href: "/reportes", tag: "Reports", status: "Activo", risk: "Medio", group: "Reports" },
  { title: "Notificaciones y Alertas", subtitle: "Vencimientos, CAPA y escalamiento", description: "Gestión de alertas, vencimientos, CAPA pendientes, auditorías, calibraciones, documentos, licencias, responsables, escalamiento, evidencia, desviaciones y cierre QA.", href: "/notificaciones", tag: "Alertas", status: "Activo", risk: "Alto", group: "Notifications" },
  { title: "CSV / DataOps", subtitle: "Importación, exportación y validación", description: "Control de importaciones, exportaciones, migraciones, conciliaciones, registros válidos, rechazados, hash, backup, evidencia, desviaciones, CAPA y decisión QA.", href: "/csv", tag: "CSV", status: "Activo", risk: "Alto", group: "DataOps" },
  { title: "Regulatorio", subtitle: "Radicaciones y autoridades", description: "Control de radicaciones regulatorias, expedientes, licencias, requerimientos, respuestas a autoridad, evidencia documental, vencimientos, QA, desviaciones y CAPA.", href: "/regulatorio", tag: "Reg", status: "Activo", risk: "Crítico", group: "Regulatory" },
  { title: "Extracción BHO", subtitle: "Closed-loop, solvente y QA", description: "Trazabilidad de extracción BHO con lote de origen, solvente documentado, sistema cerrado, purge, limpieza, seguridad, evidencia, desviaciones, CAPA y decisión QA.", href: "/bho", tag: "BHO", status: "Activo", risk: "Crítico", group: "Extraction" },
  { title: "Live Rosin", subtitle: "Solventless premium y QA", description: "Trazabilidad Live Rosin con fresh frozen, bubble hash, micronaje, press, curado, limpieza, evidencia, cuarentena, desviaciones, CAPA y decisión QA.", href: "/live-rosin", tag: "Rosin", status: "Activo", risk: "Alto", group: "Extraction" },
  { title: "Bubble Hash", subtitle: "Ice water hash y micronaje", description: "Trazabilidad Bubble Hash con material congelado, agua/hielo o consumibles críticos, bolsas micron, secado, limpieza, evidencia, cuarentena y liberación QA.", href: "/bubble-hash", tag: "Hash", status: "Activo", risk: "Alto", group: "Extraction" },
  { title: "Post-Extracción GMP", subtitle: "Purificación, fraccionamiento y QA", description: "Trazabilidad post-extracción para winterización, filtración, decarboxilación, destilación, fraccionamiento, remediación aprobada por QA, formulación intermedia, evidencia, desviaciones y CAPA.", href: "/post-extraccion", tag: "Post", status: "Activo", risk: "Alto", group: "Extraction" },
];

export const secondaryModules = [
  "Motor IA de tendencias QA",
  "Base de datos persistente",
  "Panel móvil PWA offline",
];

export const quickAccess: DashboardAction[] = [
  { href: "/reportes-programados", label: "Reportes Auto", className: "from-blue-600 to-cyan-500" },
  { href: "/riesgos", label: "Riesgos", className: "from-red-600 to-rose-500" },
  { href: "/cambios", label: "Cambios", className: "from-cyan-500 to-emerald-500" },
  { href: "/workflows", label: "Workflows", className: "from-pink-500 to-fuchsia-500" },
  { href: "/regulatoria-api", label: "Reg API", className: "from-purple-600 to-violet-500" },
  { href: "/recepcion", label: "Nuevo Registro", className: "from-emerald-600 to-green-500" },
];

export const heroAccess: DashboardAction[] = [
  { href: "/reportes-programados", label: "Abrir Reportes Auto", className: "from-blue-600 to-cyan-500" },
  { href: "/riesgos", label: "Abrir Riesgos", className: "from-red-600 to-rose-500" },
  { href: "/cambios", label: "Abrir Cambios", className: "from-cyan-500 to-emerald-500" },
  { href: "/workflows", label: "Abrir Workflows", className: "from-pink-500 to-fuchsia-500" },
];


