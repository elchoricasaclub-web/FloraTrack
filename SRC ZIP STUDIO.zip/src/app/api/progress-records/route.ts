import { NextResponse } from "next/server";
import fs from "fs";
import path from "path";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const dataDir = path.join(process.cwd(), "data");
const dataFile = path.join(dataDir, "progress-records.json");

const blockedValues = [
  "",
  "usuario actual",
  "responsable gacp",
  "guardado global seguro",
  "guardar avance actual",
  "avance guardado desde botón flotante global.",
  "avance guardado desde boton flotante global.",
  "evidencia pendiente",
  "sin evidencia",
  "n/a",
  "na"
];

function clean(value: unknown) {
  return String(value ?? "").replace(/\s+/g, " ").trim();
}

function isInvalid(value: unknown) {
  const normalized = clean(value).toLowerCase();
  return blockedValues.includes(normalized) || clean(value).length < 3;
}

function ensureStore() {
  if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true });
  }

  if (!fs.existsSync(dataFile)) {
    fs.writeFileSync(dataFile, "[]", "utf8");
  }
}

function readRecords() {
  ensureStore();

  try {
    const parsed = JSON.parse(fs.readFileSync(dataFile, "utf8"));
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

function writeRecords(records: any[]) {
  ensureStore();
  fs.writeFileSync(dataFile, JSON.stringify(records, null, 2), "utf8");
}

function isBadRecord(record: any) {
  return (
    isInvalid(record?.itemTitle) ||
    isInvalid(record?.owner) ||
    isInvalid(record?.evidence) ||
    isInvalid(record?.note) ||
    clean(record?.actionType).toLowerCase() === "safe-global-save"
  );
}

function validateInput(input: Record<string, unknown>) {
  const missing: string[] = [];

  if (isInvalid(input.itemTitle)) missing.push("Título del avance");
  if (isInvalid(input.owner)) missing.push("Responsable real");
  if (isInvalid(input.evidence)) missing.push("Evidencia real");
  if (isInvalid(input.note)) missing.push("Nota técnica");

  return missing;
}

export async function GET() {
  const records = readRecords();
  const filtered = records.filter((record: any) => !isBadRecord(record));

  if (filtered.length !== records.length) {
    writeRecords(filtered);
  }

  return NextResponse.json({
    ok: true,
    total: filtered.length,
    records: filtered.slice().reverse()
  });
}

export async function POST(request: Request) {
  const contentType = request.headers.get("content-type") || "";

  let input: Record<string, unknown> = {};

  if (contentType.includes("application/json")) {
    try {
      input = await request.json();
    } catch {
      input = {};
    }
  } else {
    const formData = await request.formData();

    for (const [key, value] of formData.entries()) {
      input[key] = String(value);
    }
  }

  const missing = validateInput(input);

  if (missing.length > 0) {
    return NextResponse.json({
      ok: false,
      error: "VALIDATION_REQUIRED",
      message: "Falta información requerida.",
      fields: missing
    }, { status: 400 });
  }

  const records = readRecords();

  const record = {
    id: `PROG-${Date.now()}`,
    createdAt: new Date().toISOString(),
    moduleName: clean(input.moduleName || "FloraTrack"),
    itemTitle: clean(input.itemTitle),
    actionType: clean(input.actionType || "validated-progress-save"),
    owner: clean(input.owner),
    status: clean(input.status || "Guardado"),
    evidence: clean(input.evidence),
    note: clean(input.note)
  };

  records.unshift(record);
  writeRecords(records);

  return NextResponse.json({
    ok: true,
    record,
    records
  });
}
