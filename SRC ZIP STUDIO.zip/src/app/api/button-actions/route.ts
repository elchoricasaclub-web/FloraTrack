import { NextResponse } from "next/server";
import fs from "fs";
import path from "path";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const dataDir = path.join(process.cwd(), "data");
const dataFile = path.join(dataDir, "button-actions.json");

function ensureStore() {
  if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true });
  }

  if (!fs.existsSync(dataFile)) {
    fs.writeFileSync(dataFile, "[]", "utf8");
  }
}

function clean(value: unknown) {
  return String(value ?? "").replace(/\s+/g, " ").trim();
}

function readActions() {
  ensureStore();

  try {
    const parsed = JSON.parse(fs.readFileSync(dataFile, "utf8"));
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

function writeActions(actions: any[]) {
  ensureStore();
  fs.writeFileSync(dataFile, JSON.stringify(actions, null, 2), "utf8");
}

export async function GET() {
  const actions = readActions();

  return NextResponse.json({
    ok: true,
    total: actions.length,
    actions: actions.slice().reverse()
  });
}

export async function POST(request: Request) {
  let body: Record<string, unknown> = {};

  try {
    body = await request.json();
  } catch {
    body = {};
  }

  const label = clean(body.label);
  const moduleName = clean(body.moduleName || "FloraTrack");
  const actionType = clean(body.actionType || "button-click");

  if (!label) {
    return NextResponse.json({
      ok: false,
      error: "LABEL_REQUIRED",
      message: "El botón no tiene etiqueta."
    }, { status: 400 });
  }

  const actions = readActions();

  const action = {
    id: `BTN-${Date.now()}`,
    createdAt: new Date().toISOString(),
    label,
    moduleName,
    actionType,
    route: clean(body.route),
    note: clean(body.note)
  };

  actions.unshift(action);
  writeActions(actions.slice(0, 500));

  return NextResponse.json({
    ok: true,
    action
  });
}
